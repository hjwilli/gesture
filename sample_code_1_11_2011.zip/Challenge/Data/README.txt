This directory should contain subdirectories:
devel01
...
devel20

valid01
...
valid20

Get data from the website of the challenge.
http://gesture.chalearn.org
